Imbalanced semiprime representations of even integers
Slava Chan, 10 October 2026

Main file: main.tex. Compile with pdfLaTeX three times.
This clean source package includes the three LaTeX files and twelve
verbatim proof modules needed to build the manuscript. The reading guide
is a separate document and is not included in this upload package.

Source and compact verification package:
https://github.com/UyNewNas/chen-imbalanced-semiprimes
Full numerical evidence and checksums:
https://github.com/UyNewNas/chen-imbalanced-semiprimes/releases/tag/v2026.10.10

Editorial correction: added Suzuki's dated notes to the bibliography and
linked the reproduction materials in the main text. Mathematical claims
and frozen proof modules are unchanged by this correction.
