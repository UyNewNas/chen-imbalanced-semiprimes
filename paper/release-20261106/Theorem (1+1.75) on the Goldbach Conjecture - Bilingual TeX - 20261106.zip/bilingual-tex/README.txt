Theorem (1+1.75) on the Goldbach Conjecture
Bilingual TeX sources - Version 20261106
Author: Slava Chan
Manuscript date: 6 November 2026

CONTENTS
en/   English manuscript (68 pages)
zh/   Chinese manuscript (57 pages)
Each directory contains main.tex and the seven TeX files it inputs.
References are contained in references.tex; BibTeX is not required.

BUILD
Use a TeX distribution with amsart, Latin Modern, AMS math packages,
mathtools, booktabs, array, longtable, mathrsfs, geometry, xurl and hyperref.
The Chinese source also requires ctex and needspace. Its existing
ctex option fontset=windows selects Windows Chinese fonts; build it with
those fonts available, as on the Windows system used for this release.

English, from en/:
    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error main.tex

Chinese, from zh/:
    xelatex -interaction=nonstopmode -halt-on-error main.tex
    xelatex -interaction=nonstopmode -halt-on-error main.tex

If a cross-reference or table-width rerun is requested, run the same
command once more. The supplied PDFs are the reference rendering.

NUMERICAL DATA
The numerical data, certificates and verification scripts are supplied
separately in the Numerical Supplement archive for version 20261106.
Supplement DOI: https://doi.org/10.5281/zenodo.23755453
